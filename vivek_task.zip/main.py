from DataValidation import DataValidation

assignObject = DataValidation()